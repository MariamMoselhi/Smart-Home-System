/*
 * USART_interface.h
 *
 *      Author  : Jimmy
        SWC     : USART
        Version : 01
 */
 
#ifndef USART_CONFIG_H_
#define USART_CONFIG_H_





#endif /* USART_CONFIG_H_ */