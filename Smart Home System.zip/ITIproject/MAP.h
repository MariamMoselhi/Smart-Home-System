#ifndef MAP_H_
#define MAP_H_

s32 Map(s32 Input_Min , s32 Input_Max , s32 Output_Min ,s32 Output_Max , s32 Input_Val);

#endif
